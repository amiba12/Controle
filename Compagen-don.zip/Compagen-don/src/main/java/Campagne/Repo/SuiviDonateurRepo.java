package Campagne.Repo;

import Campagne.entites.SuiviDonateur;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SuiviDonateurRepo extends JpaRepository<SuiviDonateur, Long> {
}
