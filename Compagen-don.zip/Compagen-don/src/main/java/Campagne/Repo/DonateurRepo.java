package Campagne.Repo;

import Campagne.entites.Donateur;
import Campagne.entites.Projection.DonateurResume;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.*;

@Repository
public interface DonateurRepo extends JpaRepository<Donateur, Long> {
    List<Donateur> findByDateFinAfter(LocalDate date);
    Optional<Donateur> findByEmail(String email);

    @Query("SELECT d FROM Donateur d ORDER BY d.objectifMontant DESC")
    List<Donateur> findTopContributors();

    @Query("SELECT d.nom AS nom, d.email AS email, d.telephone AS telephone FROM Donateur d WHERE CURRENT_DATE BETWEEN d.dateDebut AND d.dateFin")
    List<DonateurResume> findActiveDonateurs();
}

