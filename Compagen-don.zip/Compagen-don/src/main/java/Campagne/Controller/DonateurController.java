package Campagne.Controller;

import Campagne.entites.Donateur;
import Campagne.entites.Projection.DonateurResume;
import Campagne.Service.DonateurService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/donateurs")
public class DonateurController {

    @Autowired
    private DonateurService service;

    // Liste des donateurs actifs
    @GetMapping("/actifs")
    public List<DonateurResume> getActifs() {
        return service.getActiveDonateurs();
    }

    // Tous les donateurs
    @GetMapping
    public List<Donateur> getAll() {
        return service.getAll();
    }

    // Donateur par ID
    @GetMapping("/{id}")
    public ResponseEntity<Donateur> getById(@PathVariable Long id) {
        return service.getById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Créer un nouveau donateur
    @PostMapping
    public ResponseEntity<Donateur> create(@Valid @RequestBody Donateur d) {
        return new ResponseEntity<>(service.create(d), HttpStatus.CREATED);
    }

    // Modifier un donateur
    @PutMapping("/{id}")
    public ResponseEntity<Donateur> update(@PathVariable Long id, @Valid @RequestBody Donateur d) {
        return ResponseEntity.ok(service.update(id, d));
    }

    // Supprimer un donateur
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    // Donateur par email
    @GetMapping("/by-email")
    public ResponseEntity<Donateur> getByEmail(@RequestParam String email) {
        return service.getByEmail(email)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Top donateurs
    @GetMapping("/top")
    public List<Donateur> getTopContributors() {
        return service.getTopContributors();
    }
}
