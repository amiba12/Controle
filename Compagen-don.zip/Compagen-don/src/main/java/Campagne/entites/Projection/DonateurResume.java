package Campagne.entites.Projection;

public interface DonateurResume {
    String getNom();
    String getEmail();
    String getTelephone();
}

