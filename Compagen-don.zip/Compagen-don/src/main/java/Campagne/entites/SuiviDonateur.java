package Campagne.entites;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class SuiviDonateur {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Donateur campagne;

    private String nomDonateur;
    private Double montant;
    private LocalDate date;

    // Getters et setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Donateur getCampagne() { return campagne; }
    public void setCampagne(Donateur campagne) { this.campagne = campagne; }

    public String getNomDonateur() { return nomDonateur; }
    public void setNomDonateur(String nomDonateur) { this.nomDonateur = nomDonateur; }

    public Double getMontant() { return montant; }
    public void setMontant(Double montant) { this.montant = montant; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
}
