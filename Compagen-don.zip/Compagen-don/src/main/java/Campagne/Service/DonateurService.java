package Campagne.Service;



import Campagne.entites.Donateur;
import Campagne.entites.Projection.DonateurResume;
import Campagne.Repo.DonateurRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class DonateurService {

    @Autowired
    private DonateurRepo donateurRepo;

    public List<Donateur> getAll() {
        return donateurRepo.findAll();
    }

    public Optional<Donateur> getById(Long id) {
        return donateurRepo.findById(id);
    }

    public Donateur create(Donateur d) {
        return donateurRepo.save(d);
    }

    public void delete(Long id) {
        donateurRepo.deleteById(id);
    }

    public Donateur update(Long id, Donateur d) {
        d.setId(id);
        return donateurRepo.save(d);
    }

    public List<DonateurResume> getActiveDonateurs() {
        return donateurRepo.findActiveDonateurs();
    }

    public Optional<Donateur> getByEmail(String email) {
        return donateurRepo.findByEmail(email);
    }

    public List<Donateur> getTopContributors() {
        return donateurRepo.findTopContributors();
    }

    public Donateur findById(Long id) {
        return donateurRepo.findById(id).orElse(null);
    }

}
