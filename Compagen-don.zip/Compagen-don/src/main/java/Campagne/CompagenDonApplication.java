package Campagne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompagenDonApplication {

    public static void main(String[] args) {
        SpringApplication.run(CompagenDonApplication.class, args);
    }

}
